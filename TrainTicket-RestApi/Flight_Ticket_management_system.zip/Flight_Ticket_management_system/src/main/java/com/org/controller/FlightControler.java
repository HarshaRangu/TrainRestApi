package com.org.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.org.entity.Passenger_Details;
import com.org.entity.Ticket_details;
import com.org.service.FlightService;

@RestController
public class FlightControler {

	@Autowired
	private FlightService flightService;

	@PostMapping("/bookFlightTicket")
	public ResponseEntity<Ticket_details> bookTicket(@RequestBody Passenger_Details passenger) {
		Ticket_details bookTicket = flightService.bookTicket(passenger);

		return new ResponseEntity<Ticket_details>(bookTicket, HttpStatus.CREATED);

	}

	@GetMapping("/allTickets")
	public ResponseEntity<List<Ticket_details>> getAllTickets() {
		List<Ticket_details> allTickets = flightService.getAllTickets();
		return new ResponseEntity<List<Ticket_details>>(allTickets, HttpStatus.OK);

	}

	@GetMapping("/ticket/{ticNum}")
	public ResponseEntity<Ticket_details> getTicketById(@PathVariable("ticNum") String ticketNumber) {
		Ticket_details ticket = flightService.getTicket(ticketNumber);
		return new ResponseEntity<Ticket_details>(ticket, HttpStatus.OK);

	}

	@PutMapping("/updateTicket")
	public ResponseEntity<String> updateTicket(@RequestBody Ticket_details ticket) {
		String updateTicket = flightService.updateTicket(ticket);
		return new ResponseEntity<String>(updateTicket, HttpStatus.OK);

	}

	@DeleteMapping("/deleteTicket")
	public ResponseEntity<String> deleteTicket(Integer ticketId) {
		String deleteTicket = flightService.deleteTicket(ticketId);
		return new ResponseEntity<String>(deleteTicket, HttpStatus.OK);

	}

}
